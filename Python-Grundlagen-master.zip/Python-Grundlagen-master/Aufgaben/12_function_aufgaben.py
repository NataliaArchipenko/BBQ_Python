import math


# Schreibe eine Funktion zur Berechnung der Fläche eines Quadrates



# Schreibe eine Funktion zur Berechnung der Fläche eines Rechteckes



# Schreibe eine Funktion zur Berechnung der Fläche eines Kreises



# Schreibe eine Funktion die 2 Zahlen als übergabe Parameter bekommt und die größere Zahl wieder gibt



# Schreibe eine Funktion die überprüft, ob eine Zahl positiv negativ oder null ist.





