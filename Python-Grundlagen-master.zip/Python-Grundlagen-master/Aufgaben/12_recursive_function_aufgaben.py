# Schreibe eine rekursive Funktion power(x, n), die die Potenz x hoch n berechnet.
# Schreibe eine rekursive Funktion, die Summe aller Zahlen in einer gegebenen Liste berechnet
# Schreibe eine rekursive Funktion, die die Fakultät einer Zahl n berechnet.
# Schreibe eine rekursive Funktion reverse_string(s), die eine Zeichenkette s umkehrt.
# Schreibe eine rekursive Funktion is_palindrome(s), die überprüft, ob eine Zeichenkette s ein Palindrom ist.
# Schreibe eine rekursive Funktion count_consonants(s), die die Anzahl der Konsonanten in einer Zeichenkette s zählt.