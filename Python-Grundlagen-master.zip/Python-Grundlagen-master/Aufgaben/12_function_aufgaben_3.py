# Schreibe eine Funktion, die überprüft, ob eine Zahl zwischen 10 und 20 liegt

# Schreibe eine Funktion, die überprüft, ob eine Zahl entweder kleiner als 5 oder größer als 15 ist.

# Eine Funktion mit 2 Parametern die überprüft ob genau eine True ist.

# Schreibe eine Funktion, die überprüft, ob eine Zahl sowohl durch 2 als auch durch 5 teilbar ist.

# Schreibe eine Funktion mit 3 Parametern par_1 = bool par_2 = bool und par_3 = string
# Der String soll entweder and, or oder xor.
# Die Funktion soll eine Art Logische Operator Taschenrechner werden

# True True and  -> Ausgabe True
# True True or  -> Ausgabe True
# True True xor  -> Ausgabe False
