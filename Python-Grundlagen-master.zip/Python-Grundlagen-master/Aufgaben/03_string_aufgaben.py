# Erstelle einen Variable my_var und weise ihr den wert "Hallo Welt" zu

# Erstelle eine Variable erster und weise ihr den Ersten Buchstaben des Strings my_var zu

# Erstelle eine Variable letzter und weise ihr den letzten Buchstaben des Strings my_var zu

# Schneide aus dem String in my_var das Wort Hallo aus und weise es der Variable hallo zu.

# Schneide aus dem String in my_var das Wort Welt aus und weise es der Variable welt zu.

# Tausche den Wert der Variablen hallo und welt

alphabet = "abcdefghijklmnopqrstuvwxyz "

# Erstelle eine Variable name und weise ihr den Vor- und Nachnamen bob studehi zu.
# Benutze dafür nur die Buchstaben aus der Variable alphabet

# Ändere mithilfe der upper Methode den Anfangsbuchstaben des Vor- und Nachnamens

# Printe den Nachnahmen mit Slicen der name Variable

# Erstelle eine Variable name_9999, in der dein Name 9999-mal gespeichert ist






