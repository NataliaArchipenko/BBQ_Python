# Erstelle ein leeres Dictionary namens my_dict.
# Fülle das Dictionary my_dict mit drei Schlüssel-Wert-Paaren:
# "Apfel" mit dem Wert 3, "Banane" mit dem Wert 2 und "Orange" mit dem Wert 5.

# Drucke den Wert für den Schlüssel "Banane" aus.
# Überprüfe, ob der Schlüssel "Traube" im Dictionary my_dict vorhanden ist.
# Füge dem Dictionary my_dict einen neuen Eintrag hinzu: "Traube" mit dem Wert 4.
# Aktualisiere den Wert für den Schlüssel "Apfel" auf 6.
# Lösche den Eintrag für den Schlüssel "Orange" aus dem Dictionary.
# Drucke alle Schlüssel in my_dict aus.
# Drucke alle Werte in my_dict aus.
# Drucke alle Schlüssel-Wert-Paare in my_dict aus
