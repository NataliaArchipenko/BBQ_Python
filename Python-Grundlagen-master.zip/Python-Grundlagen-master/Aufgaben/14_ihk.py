# Sommer 2022 Ap1
PCNr = 1
SoftwareNr = 1
PcListe = []
SoftwareListe = []


def getPC():
	return ['Pc1', 'Pc2', 'Pc3', 'Pc4', 'Pc5', 'Pc6']


def getSoftware(pc):
	if True:
		pass
	return ['Word', 'Teams', 'Powerpoint', 'Excel']


def installSoftware(software, pc):
	print(f'{software} auf {pc} installiert')


# -----------------------------------------------------------------------
# Herbst 2022 Ap1
def setRollerDim(breite, länge, dicke):
	print(f"{breite}, {länge} und {dicke} eingestellt")


def getEmergencyStop():
	return False


def rollerStart():
	print(f'Wellpappe erstellt')


def launchTask(result):
	pass


# --------------------------------------------------
# Sommer Ap2-1
werte = [30, 24, 12, 50, 11, 49, 11]  # Beispeil Werte
temp = None
len_ = len(werte)  # Länge des arrays
for p in range(0, len_ - 1, 1):  # äußere Schleife
	pass
