# from var_and_func import *
import var_and_func as alias
print(alias.my_dict)
print(my_func(2))