# Zahlen addieren:
# Schreibe eine While-Schleife,
# die die Summe von Zahlen von 1 bis zu einer vom Benutzer
# eingegebener Zahl berechnet.


# Passwort überprüfen:
# Erstelle eine Schleife,
# die den Benutzer nach einem Passwort fragt,
# bis das korrekte Passwort eingegeben wird.
password = 'G3h31m'

# Ein Spieler soll eine (zufällig gewählte) Zahl zwischen 1 und 100 erraten.
# Das Programm soll jeweils die Meldungen „Die Zahl ist zu groß“,
# „Die Zahl ist zu klein“ bzw.
# „Treffer“ ausgeben.
# Wenn die Zahl zu Gross oder zu klein ist soll die Frage erneut gestellt werden

import random

zufall_zahl = random.randint(1, 100)
