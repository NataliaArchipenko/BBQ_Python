def test(a):
	a[0] += 1
	print(a)

b = [12]
test(b)
print(b)