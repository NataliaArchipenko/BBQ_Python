# Schreibe eine Funktion 'get_durchschnitt', die eine Liste von Zahlen erhaelt und den Durchschnitt
# dieser Liste returned
zahlen = [10, 20, 30, 40, 50]

# Schreibe eine Funktion 'get_durchschnitt_unbekannt', die eine unbestimmte Anzahl von Parametern  von Zahlen erhaelt
# und den Durchschnitt dieser Parameter returned





# Schreibe eine Funktion, die eine Liste von Zahlen nimmt
# und eine neue Liste mit den Quadraten dieser Zahlen zurückgibt
zahlen = [2, 4, 6, 8, 10]  # -> # Sollte [4, 16, 36, 64, 100] ergeben
# Schreibe eine Funktion, die eine unbestimmte Anzahl von Parametern von Zahlen nimmt
# und eine Liste mit den Quadraten dieser Zahlen zurückgibt


# Schreibe eine Funktion,
# die das Maximum und das Minimum aus einer
# Liste von Zahlen zurückgibt. (wenn es geht ohne min() und max())
# return [ min ,max]



# Schreibe die Funktionen zur Überprüfung der Sieg bedingungen des Tic Tac Toe spiels.
# Sie sollen True zurückgeben bei einem Sieg und False wenn sie nicht erfüllt werden
# waagerechter Sieg
spielfeld = [["-", "-", "-"], ["-", "-", "-"], ["-", "-", "-"]]

# [x, x, x]
# [-, o, o]
# [o, -, o]


# senkrechter Sieg

# [x, x, o]
# [-, o, o]
# [o, -, o]

# diagonaler Sieg oben links nach unten Rechts
# [o, x, x]
# [-, o, o]
# [o, -, o]

# diagonaler Sieg unten links nach oben Rechts
# [x, x, o]
# [-, o, o]
# [o, -, o]


# Schreibe eine Funktion, die überprüft,
# ob ein gegebener Text ein Palindrom ist
# (d.h., vorwärts und rückwärts gelesen dasselbe ist
# return True wenn palindrom
# https://de.wikipedia.org/wiki/Liste_deutscher_Palindrome



