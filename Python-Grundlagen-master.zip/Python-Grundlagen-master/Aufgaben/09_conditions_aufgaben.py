# # Der User wird nach einer Zahl gefragt und es soll ausgegeben werden ob die Zahl = < oder > 10

#
# # Der User wird nach einer Zahl gefragt. Es soll geprüft werden ob es eine gerade oder ungerade Zahl ist


# Schreibe ein Programm, das den Benutzer nach einem Passwort fragt und prüft, ob es mindestens 8 Zeichen lang ist.

# Der User wird nach einer Zahl zwischen 1-7 gefragt
# 1 Montag 2 Dienstag 3 Mittwoch 4 Donnerstag 5 Freitag 6 Samstag 7 Sonntag
# Bei anderen eingaben "keine gültige Eingabe"

# Der User wird nach seiner Punktzahl gefragt
# sehr gut 100 - 92
# gut       91 - 81
# befriedigend 80 - 67
# ausreichend 66 - 50
# mangelhaft 49 - 30
# ungenügend 29 - 0
# Bei anderen eingaben "keine gültige Eingabe"
