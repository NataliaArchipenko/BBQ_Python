# Schreibe ein Programm das die folgende Tabelle ausgibt

# Name    Alter    Ort
# --------------------
# Alice   25       New York
# Bob     30       London
# Tim     22       Paris


# Schreibe ein Programm das den folgenden Text ausgibt
# Twinkle, Twinkle, little star,
#		  How I wonder what you are!
#				Up above the world so high
#				Like a diamond in the sky
# Twinkle, Twinkle, little star,
#		  How I wonder what you are




# Ändere folgenden Code das als ausgabe
# Hallo***Welt***ich---bin+++Bob

print("Hallo", "Welt", "ich",)
print("bin", "Bob")


# Printe den folgenden Pfeil mit so wenig Functions aufrufen wie möglich
#
#      *
#     * *
#    *   *
#   *     *
#  ***   ***
#    *   *
#    *   *
#    *****
# Printe 2 Pfeile nebeneinander
# Tipp probiere mal "text" * 2



